export default {

  navigator: {
    doc: "展示中文"
  }
};
