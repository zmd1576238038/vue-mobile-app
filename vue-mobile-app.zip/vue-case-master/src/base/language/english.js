export default {

  navigator: {
    doc: "SHOW ENGLISH"
  }
};
