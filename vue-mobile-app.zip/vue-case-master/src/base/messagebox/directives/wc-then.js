export default {
  bind (el) {
    el.classList.add("wc-messagebox__btn--then");
  }
};
