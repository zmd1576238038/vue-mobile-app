<template>
  <div class="category">

  </div>
</template>

<script type="text/ecmascript-6">
export default {

};
</script>

<style lang="scss">
.category{
}
</style>


